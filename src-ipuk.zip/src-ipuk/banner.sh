#!/bin/bash
nano /etc/issue.net