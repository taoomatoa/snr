#!/bin/bash

clear
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m${NC}"
echo -e "\E[45;1;39m          ⇱ SC PREMIUM ⇲                        \E[0m"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m${NC}"
echo -e "\033[0;35m ✘\033[0m For Debian 10 64 bit                          "
echo -e "\033[0;35m ✘\033[0m For Ubuntu 18.04 & Ubuntu 20.04 64 bit        "
echo -e "\033[0;35m ✘\033[0m For VPS with KVM and VMWare virtualization    "
echo -e "\033[0;35m ✘\033[0m Build Up By FRANATA STORE                       "
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m${NC}"
echo -e "\E[45;1;39m          ⇱ THANKS TO ⇲                         \E[0m"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m${NC}"
echo -e "\033[0;35m ❀\033[0m Allah SWT                                     "
echo -e "\033[0;35m ❀\033[0m FranataSTORE                                     "
echo -e "\033[0;35m ❀\033[0m Buy: 082241967317                                        "
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m${NC}"
echo -e "\E[45;1;39m          ⇱ FRANATA-STORE ⇲                     \E[0m"
echo -e "${CYAN}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\033[0m${NC}"